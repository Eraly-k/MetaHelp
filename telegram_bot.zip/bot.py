from telegram import Update, Bot
from telegram.ext import Updater, CommandHandler, CallbackContext

TOKEN = "ВСТАВЬ_СВОЙ_ТОКЕН_СЮДА"

def start(update: Update, context: CallbackContext):
    update.message.reply_text("Привет! Я твой бот 👋")

def main():
    updater = Updater(TOKEN)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
